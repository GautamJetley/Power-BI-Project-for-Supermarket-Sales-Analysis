# Super market sales analysis using Power BI
Super market sales data is collected from Kaggle. Some Data preprocessing techniques is applied and Power BI is used to perform analysis. A dashboard is created using various graphs and charts.

## Tools Used:
1. Python
2. Pandas
3. Power BI

## Graphs and Charts list:
1. Line Chart
2. Pie Chart
3. Donut Chart
4. Gauge
5. Card
6. Slicer

## Dashboard Image

![Logistic Regression algorithm](https://github.com/Rafsun001/power-bi-project-for-resume/blob/main/project%20sample%20image.png?raw=true)
